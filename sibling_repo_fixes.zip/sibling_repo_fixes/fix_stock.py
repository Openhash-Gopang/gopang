#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
K-21 정리 — stock 저장소의 stale 임시 스크립트/OS 잔재 삭제.

전부 사전 확인 완료: 저장소 내 다른 어떤 파일에서도 참조되지 않음
desktop.ini는 Windows 탐색기가 자동 생성하는 폴더 메타파일(아이콘 지정용) —
실수로 커밋된 OS 잔재, git에 있을 이유가 없음.
(git index 외 참조 없음 확인, grep -rl 결과 없음).

실행 위치: stock 저장소 루트
"""
import os

TARGETS = [
    'desktop.ini',
]

removed = 0
for f in TARGETS:
    if os.path.exists(f):
        os.remove(f)
        print(f"[OK] 삭제: {f}")
        removed += 1
    else:
        print(f"[SKIP] 이미 없음: {f}")

print()
print(f"완료 — {removed}개 삭제")
