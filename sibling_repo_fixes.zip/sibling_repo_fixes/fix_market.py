#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
K-21 정리 — market 저장소의 stale 임시 스크립트/OS 잔재 삭제.

전부 사전 확인 완료: 저장소 내 다른 어떤 파일에서도 참조되지 않음
(old16.txt/old18.txt는 check16c.py/patch18b.py가 참조하지만, 그 두 스크립트
자체도 이미 자기 목적을 다한 1회성 마이그레이션 스크립트라 함께 삭제 — 
check16c.py로 실제 실행해 webapp.html에 old16이 더 이상 없음을 확인함,
즉 이 클러스터 전체가 죽은 코드).
(git index 외 참조 없음 확인, grep -rl 결과 없음).

실행 위치: market 저장소 루트
"""
import os

TARGETS = [
    'fix.py',
    'patch16.py',
    'patch16b.py',
    'patch17.py',
    'patch18.py',
    'patch18b.py',
    'check16.txt',
    'check16b.py',
    'check16c.py',
    'old16.txt',
    'old18.txt',
]

removed = 0
for f in TARGETS:
    if os.path.exists(f):
        os.remove(f)
        print(f"[OK] 삭제: {f}")
        removed += 1
    else:
        print(f"[SKIP] 이미 없음: {f}")

# .wrangler/cache/ — Cloudflare Wrangler CLI 캐시(계정 이메일 포함), git 추적 대상 아님
wrangler_cache = '.wrangler/cache/wrangler-account.json'
if os.path.exists(wrangler_cache):
    os.remove(wrangler_cache)
    print(f"[OK] 삭제: {wrangler_cache} (계정 이메일 포함 — 공개저장소에 있으면 안 됨)")
    removed += 1
# 재발 방지 — .gitignore에 .wrangler/ 추가
gi = '.gitignore'
gi_content = open(gi, encoding='utf-8').read() if os.path.exists(gi) else ''
if '.wrangler/' not in gi_content:
    with open(gi, 'a', encoding='utf-8') as f:
        f.write(('\n' if gi_content and not gi_content.endswith(chr(10)) else '') + '.wrangler/\n')
    print("[OK] .gitignore에 .wrangler/ 추가(재발 방지)")
else:
    print("[SKIP] .gitignore에 이미 .wrangler/ 있음")

print()
print(f"완료 — {removed}개 삭제")
