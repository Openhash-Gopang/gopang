#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
K-21 정리 — health 저장소의 stale 임시 스크립트/OS 잔재 삭제.

전부 사전 확인 완료: 저장소 내 다른 어떤 파일에서도 참조되지 않음
(git index 외 참조 없음 확인, grep -rl 결과 없음).

실행 위치: health 저장소 루트
"""
import os

TARGETS = [
    'fix_health.py',
]

removed = 0
for f in TARGETS:
    if os.path.exists(f):
        os.remove(f)
        print(f"[OK] 삭제: {f}")
        removed += 1
    else:
        print(f"[SKIP] 이미 없음: {f}")

print()
print(f"완료 — {removed}개 삭제")
