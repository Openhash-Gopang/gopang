#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
K-21 추가 정리 — docs/SP-TAX_ktax_v2_0.txt가 prompts/SP-TAX_ktax_v2_0.txt와
byte-for-byte 완전히 동일한 파일임을 diff로 확인(우발적 중복, 의도된 문서화
사본 아님). prompts/ 쪽을 정본으로 남기고 docs/ 쪽 중복을 삭제한다.

이 스크립트는 fix_tax.py(stale fix_svc_id.py/fix_tax.py 삭제)와 별도로
실행해도 안전 — 서로 다른 파일을 건드림.

실행 위치: tax 저장소 루트
"""
import filecmp
import os

A = "prompts/SP-TAX_ktax_v2_0.txt"
B = "docs/SP-TAX_ktax_v2_0.txt"

if not os.path.exists(B):
    print(f"[SKIP] 이미 없음: {B}")
elif not os.path.exists(A):
    print(f"[FAIL] 정본이 없음: {A} — 삭제 보류(안전 확인 실패)")
elif not filecmp.cmp(A, B, shallow=False):
    print(f"[FAIL] {A}와 {B}가 더 이상 동일하지 않음 — 내용이 갈라진 걸 수 있어 자동 삭제 보류")
else:
    os.remove(B)
    print(f"[OK] 삭제: {B} (정본 {A}와 완전 동일 확인 후 중복만 제거)")
